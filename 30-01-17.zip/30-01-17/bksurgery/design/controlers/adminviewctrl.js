vangular.module("med").controller("adminviewctrl",function ($scope,$rootScope,$http){

var adminApi="/admin/bsr/viewAll";

var response=$http({
    method: 'GET',
    url: adminApi
});response.then(function(result){
	$scope.viewAdmin=result.data;
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});
});


