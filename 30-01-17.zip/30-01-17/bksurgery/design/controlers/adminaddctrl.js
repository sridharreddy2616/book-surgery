angular.module("med").controller("adminaddctrl",function ($scope,$rootScope,$http){

	var adminApi="/admin/bsr/add";
	$scope.abc=function(){
		var username=$scope.username;
		var password=$scope.password;
		console.log(username+password);
		var response=$http.post(adminApi,{'name':username});
		
response.then(function(result){
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});
	
	
}

});




