angular.module("med").controller("procedureaddctrl",function ($scope,$rootScope,$http){

  var api="/procedure/bsr/add";
	$scope.abc=function(){		
	var cntDepartment=$scope.cntDepartment;
	var cntProcedure=$scope.cntProcedure;
	var cntProcedureid=$scope.cntProcedureid;
	console.log(cntDepartment+cntProcedure+cntProcedureid);
/*var response=$http({
    method: 'POST',
    url: countryApi,
    data: 'name='+ countryName
});*/
var response=$http.post(api,{'name':cntDepartment});
response.then(function(result){
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});	
}
});
