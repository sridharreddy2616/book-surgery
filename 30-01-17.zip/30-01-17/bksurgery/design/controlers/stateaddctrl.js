angular.module("med").controller("stateaddctrl",function ($scope,$rootScope,$http){

	var stateApi="/state/bsr/add";
	$scope.abc=function(){		
	var stateName=$scope.stateName;
	var stateId=$scope.stateId;
	var countryid=$scope.countryid;
	console.log(stateName+stateId+countryid);
/*var response=$http({
    method: 'POST',
    url: countryApi,
    data: 'name='+ countryName
});*/
var response=$http.post(stateApi,{'name':stateName});
response.then(function(result){
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});
	
	
}
});

