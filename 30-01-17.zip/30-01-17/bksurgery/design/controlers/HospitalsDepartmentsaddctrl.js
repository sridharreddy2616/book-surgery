angular.module("med").controller("HospitalsDepartmentsaddctrl",function ($scope,$rootScope,$http){

var hospitalsdepartmentApi="/HospitalsDepartments/bsr/add";
	$scope.abc=function(){		
	var hospitalid=$scope.hospitalid;
	var departmentid=$scope.departmentid;
	console.log(hospitalid+departmentid);

var response=$http.post(hospitalsdepartmentApi,{'name':hospitalid});
response.then(function(result){
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});
	
	
}

});




