angular.module("med").controller("surgeonviewctrl",function ($scope,$rootScope,$http){

	var surgeonApi="/surgeon/bsr/viewAll";

var response=$http({
    method: 'GET',
    url: surgeonApi
});response.then(function(result){
	$scope.viewSurgeon=result.data;
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});

});
