angular.module("med").controller("homectrl",function($scope,$rootScope){

		
	
});