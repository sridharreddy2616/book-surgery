angular.module("med").controller("HospitalDoctoraddctrl",function ($scope,$rootScope,$http){

	var hospitaldoctorApi="hospitaldoctor/bsr/add";
	$scope.abc=function(){
		// var HospitalDoctor_name=$scope.HospitalDoctor_name;
	var doctorname=$scope.doctorname;
	var doctordesignation=$scope.doctordesignation;
	var doctorexperience=$scope.doctorexperience;
	var doctordepertment=$scope.doctordepertment;
	var doctorid=$scope.doctorid;
	//var HospitalId=$scope.HospitalId;

		console.log(doctorname+doctordesignation+doctorexperience+doctordepertment+doctorid);
		var response=$http.post(hospitaldoctorApi,{'name':doctorname});
		
response.then(function(result){
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});
	
	
}

});

