angular.module("med").controller("cityviewctrl",function ($scope,$rootScope,$http){

	var cityApi="/city/bsr/viewAll";

var response=$http({
    method: 'GET',
    url: cityApi
});response.then(function(result){
	$scope.viewCity=result.data;
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});
});

