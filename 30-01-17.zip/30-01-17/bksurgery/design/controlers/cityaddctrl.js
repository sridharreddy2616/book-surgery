angular.module("med").controller("cityaddctrl",function ($scope,$rootScope,$http){

	var cityApi="/city/bsr/add";
	$scope.abc=function(){		
	var countryId=$scope.countryId;
	var stateId=$scope.stateId;
	var cityName=$scope.cityName;
	var cityId=$scope.cityId;
	console.log(countryId+stateId+cityName+cityId);
/*var response=$http({
    method: 'POST',
    url: countryApi,
    data: 'name='+ countryName
});*/
var response=$http.post(cityApi,{'name':cityName});
response.then(function(result){
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});	
}
});

