angular.module("med").controller("surgeonaddctrl",function ($scope,$rootScope,$http){

  var surgeonApi="/surgeon/bsr/add";
	$scope.abc=function(){		
	var surgeon_name=$scope.surgeon_name;
	var surgeon_degignation=$scope.surgeon_degignation;
	var state_experience=$scope.state_experience;
	var surgeon_mailid=$scope.surgeon_mailid;
	var surgeon_phonenumber=$scope.surgeon_phonenumber;
	var surgeon_picture=$scope.surgeon_picture;
	var surgeon_description=$scope.surgeon_description;
	var surgeon_date=$scope.surgeon_date;
	console.log(surgeon_name+surgeon_degignation+state_experience+surgeon_mailid+surgeon_phonenumber+surgeon_picture+surgeon_description+surgeon_date);
/*var response=$http({
    method: 'POST',
    url: countryApi,
    data: 'name='+ countryName
});*/
var response=$http.post(surgeonApi,{'name':surgeon_name});
response.then(function(result){
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});	
}
});
