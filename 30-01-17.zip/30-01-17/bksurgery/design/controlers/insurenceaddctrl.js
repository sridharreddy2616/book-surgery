angular.module("med").controller("insurenceaddctrl",function ($scope,$rootScope,$http){

  var insurenceApi="/insurence/bsr/add";
	$scope.abc=function(){		
	var name=$scope.name;	
	var insurencename=$scope.insurencename;
	var photo=$scope.photo;
	console.log(name+insurencename+photo);
/*var response=$http({
    method: 'POST',
    url: countryApi,
    data: 'name='+ countryName
});*/
var response=$http.post(insurenceApi,{'name':name});
response.then(function(result){
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});	
}
});
