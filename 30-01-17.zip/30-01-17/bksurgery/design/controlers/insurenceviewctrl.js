angular.module("med").controller("insurenceviewctrl",function ($scope,$rootScope,$http){

	
	var insurenceApi="/insurence/bsr/viewAll";

var response=$http({
    method: 'GET',
    url: insurenceApi
});response.then(function(result){
	$scope.viewInsurence=result.data;
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});

});
