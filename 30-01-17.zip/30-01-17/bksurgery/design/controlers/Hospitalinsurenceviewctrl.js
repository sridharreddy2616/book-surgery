angular.module("med").controller("Hospitalinsurenceviewctrl",function ($scope,$rootScope,$http){

	
	var hospitalinsurenceApi="/hospitalinsurence/bsr/viewAll";

var response=$http({
    method: 'GET',
    url: hospitalinsurenceApi
});response.then(function(result){
	$scope.viewhospitalinsurence=result.data;
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});

});
