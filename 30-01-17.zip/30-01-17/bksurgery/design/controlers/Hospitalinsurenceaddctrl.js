angular.module("med").controller("Hospitalinsurenceaddctrl",function ($scope,$rootScope,$http){

  var hospitalinsurenceApi="/hospitalinsurence/bsr/add";
	$scope.abc=function(){		
	var hospitalid=$scope.hospitalid;	
	var insurenceid=$scope.insurenceid;
	
	console.log(hospitalid+hospitalid);
/*var response=$http({
    method: 'POST',
    url: countryApi,
    data: 'name='+ countryName
});*/
var response=$http.post(hospitalinsurenceApi,{'name':hospitalid});
response.then(function(result){
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});	
}

});
