angular.module("med").controller("HospitalDoctorviewctrl",function ($scope,$rootScope,$http){

	var hospitaldoctorApi="/hospitaldoctor/bsr/viewAll";

var response=$http({
    method: 'GET',
    url: hospitaldoctorApi
});response.then(function(result){
	$scope.viewHospitalDoctor=result.data;
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});
});