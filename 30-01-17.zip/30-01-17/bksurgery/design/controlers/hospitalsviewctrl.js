angular.module("med").controller("hospitalsviewctrl",function ($scope,$rootScope,$http){

	var hospetalsApi="/hospetals/bsr/viewAll";

var response=$http({
    method: 'GET',
    url: hospetalsApi
});response.then(function(result){
	$scope.viewhospitals=result.data;
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});
});