angular.module("med").controller("adminctrl",function ($scope){
	$scope.usersubmit=function(){
		alert("this is adminctrl");
		

	}
});

