angular.module("med").controller("hospitalsaddctrl",function ($scope,$rootScope,$http){

	var hospetalsApi="hospetals/bsr/add";
	$scope.abc=function(){
	var hospital_name=$scope.hospital_name;
	var hospital_id=$scope.hospital_id;
	var country_name=$scope.country_name;
	var state_name=$scope.state_name;
	var city_name=$scope.city_name;
	var city_id=$scope.city_id;
	var department_id=$scope.department_id;
	var area_name=$scope.area_name;
	var pincode_name=$scope.pincode_name;
	var logitude=$scope.logitude;
	var latitude=$scope.latitude;
	var description=$scope.description;
	var crdate=$scope.crdate;
		console.log(hospital_name+hospital_id+country_name+state_name+city_name+city_id+department_id+area_name+pincode_name+logitude+latitude+description+crdate);
		var response=$http.post(hospetalsApi,{'name':hospital_name});
		
response.then(function(result){
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});
}
});

