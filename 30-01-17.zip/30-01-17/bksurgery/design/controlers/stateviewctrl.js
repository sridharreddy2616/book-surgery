angular.module("med").controller("stateviewctrl",function ($scope,$rootScope,$http){

var stateApi="/state/bsr/viewAll";

var response=$http({
    method: 'GET',
    url: stateApi
});response.then(function(result){
	$scope.viewState=result.data;
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});

});



