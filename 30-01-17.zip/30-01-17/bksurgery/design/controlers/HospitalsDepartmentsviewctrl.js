angular.module("med").controller("HospitalsDepartmentsviewctrl",function ($scope,$rootScope,$http){

	var hospitalsdepartmentApi="/hospitalsdepartments/bsr/viewAll";

var response=$http({
    method: 'GET',
    url: hospitalsdepartmentApi
});response.then(function(result){
	$scope.viewhospitalsdepartments=result.data;
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});
});




