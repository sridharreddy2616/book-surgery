angular.module("med").controller("addctrl",function ($scope,$rootScope,$http){

var countryApi="/country/bsr/add";
	$scope.abc=function(){		
	var countryName=$scope.countryName;
	var countryId=$scope.countryId;
	console.log(countryName+countryId);
/*var response=$http({
    method: 'POST',
    url: countryApi,
    data: 'name='+ countryName
});*/
var response=$http.post(countryApi,{'name':countryName});
response.then(function(result){
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});	
$scope.dba="Sridhar";
}
});

