angular.module("med").controller("procedureviewctrl",function ($scope,$rootScope,$http){

	var api="/procedure/bsr/viewAll";

var response=$http({
    method: 'GET',
    url: api
});response.then(function(result){
	$scope.viewProcedure=result.data;
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});

});
