angular.module("med").controller("viewctrl",function ($scope,$rootScope,$http){

var countryApi="/country/bsr/viewAll";

var response=$http({
    method: 'GET',
    url: countryApi
});response.then(function(result){
$scope.viewCountry=result.data;
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});

$scope.delrow=function(row){
      var vip=row.$remove(row);
      vip.then(function(result){
         console.log(result);

         $scope.viewSuccess="yes successfully row deleted"

      }),function(result){
         console.log(result);

         $scope.viewSuccess="no row not deleted"

      }

   }

 

});
