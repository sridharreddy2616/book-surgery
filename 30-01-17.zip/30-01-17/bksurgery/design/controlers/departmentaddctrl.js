angular.module("med").controller("departmentaddctrl",function ($scope,$rootScope,$http){

var departmentApi="/department/bsr/add";
	$scope.abc=function(){		
	var departmentname=$scope.departmentname;
	var departmentid=$scope.departmentid;
	var categories=$scope.categories;
	console.log(departmentname+departmentid+categories);

var response=$http.post(departmentApi,{'name':departmentname,departmentid,categories});
response.then(function(result){
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});	
}
});




