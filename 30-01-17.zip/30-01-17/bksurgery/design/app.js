angular.module("med",['ui.router','ui.bootstrap','angularUtils.directives.dirPagination']);
angular.module("med").config(function($stateProvider,$urlRouterProvider){
$stateProvider.state("adminadd",{
	url:"/adminadd",
	views:{
	"adminadd":{
	templateUrl:"templates/adminadd.html",
	controller:"adminaddctrl",
	controllerAs:"adminadd"

}
}

}).state("adminview",{
	url:"/adminview",
	views:{
	"adminview":{
	templateUrl:"templates/adminview.html",
	controller:"adminviewctrl",
	controllerAs:"adminview"

}
}

}).state("add",{
	url:"/add",
	views:{
	"add":{
	templateUrl:"templates/add.html",
	controller:"addctrl",
	controllerAs:"coun"

}
}

}).state("view",{
	url:"/view",
	views:{
	"view":{
	templateUrl:"templates/view.html",
	controller:"viewctrl",
	controllerAs:"view"

}
}

}).state("stateadd",{
	url:"/stateadd",
	views:{
	"stateadd":{
	templateUrl:"templates/stateadd.html",
	controller:"stateaddctrl",
	controllerAs:"stateadd"

}
}

}).state("stateview",{
	url:"/stateview",
	views:{
	"stateview":{
	templateUrl:"templates/stateview.html",
	controller:"stateviewctrl",
	controllerAs:"stateview"

}
}

}).state("cityadd",{
	url:"/cityadd",
	views:{
	"cityadd":{
	templateUrl:"templates/cityadd.html",
	controller:"cityaddctrl",
	controllerAs:"cityadd"

}
}

}).state("cityview",{
	url:"/cityview",
	views:{
	"cityview":{
	templateUrl:"templates/cityview.html",
	controller:"cityviewctrl",
	controllerAs:"cityview"

}
}

}).state("departmentadd",{
	url:"/departmentadd",
	views:{
	"departmentadd":{
	templateUrl:"templates/departmentadd.html",
	controller:"departmentaddctrl",
	controllerAs:"departmentadd"

}
}

}).state("departmentview",{
	url:"/departmentview",
	views:{
	"departmentview":{
	templateUrl:"templates/departmentview.html",
	controller:"departmentviewctrl",
	controllerAs:"departmentview"

}
}

}).state("procedureadd",{
	url:"/procedureadd",
	views:{
	"procedureadd":{
	templateUrl:"templates/procedureadd.html",
	controller:"procedureaddctrl",
	controllerAs:"procedureadd"

}
}

}).state("procedureview",{
	url:"/procedureview",
	views:{
	"procedureview":{
	templateUrl:"templates/procedureview.html",
	controller:"procedureviewctrl",
	controllerAs:"procedureview"

}
}

}).state("hospitalsadd",{
	url:"/hospitalsadd",
	views:{
	"hospitalsadd":{
	templateUrl:"templates/hospitalsadd.html",
	controller:"hospitalsaddctrl",
	controllerAs:"hospitalsadd"

}
}

}).state("hospitalsview",{
	url:"/hospitalsview",
	views:{
	"hospitalsview":{
	templateUrl:"templates/hospitalsview.html",
	controller:"hospitalsviewctrl",
	controllerAs:"hospitalsview"

}
}

}).state("surgeonadd",{
	url:"/surgeonadd",
	views:{
	"surgeonadd":{
	templateUrl:"templates/surgeonadd.html",
	controller:"surgeonaddctrl",
	controllerAs:"surgeonadd"

}
}
}).state("surgeonview",{
	url:"/surgeonview",
	views:{
	"surgeonview":{
	templateUrl:"templates/surgeonview.html",
	controller:"surgeonviewctrl",
	controllerAs:"surgeonview"

}
}
}).state("proceduresadd",{
	url:"/proceduresadd",
	views:{
	"proceduresadd":{
	templateUrl:"templates/proceduresadd.html",
	controller:"proceduresaddctrl",
	controllerAs:"proceduresadd"

}
}

}).state("proceduresview",{
	url:"/proceduresview",
	views:{
	"proceduresview":{
	templateUrl:"templates/proceduresview.html",
	controller:"proceduresviewctrl",
	controllerAs:"proceduresview"

}
}
}).state("insurenceadd",{
	url:"/insurenceadd",
	views:{
	"insurenceadd":{
	templateUrl:"templates/insurenceadd.html",
	controller:"insurenceaddctrl",
	controllerAs:"insurenceadd"

}
}

}).state("insurenceview",{
	url:"/insurenceview",
	views:{
	"insurenceview":{
	templateUrl:"templates/insurenceview.html",
	controller:"insurenceviewctrl",
	controllerAs:"insurenceview"
}
}

}).state("HospitalsDepartmentsadd",{
	url:"/HospitalsDepartmentsadd",
	views:{
	"HospitalsDepartmentsadd":{
	templateUrl:"templates/HospitalsDepartmentsadd.html",
	controller:"HospitalsDepartmentsaddctrl",
	controllerAs:"HospitalsDepartmentsadd"

}
}
}).state("HospitalsDepartmentsview",{
	url:"/HospitalsDepartmentsview",
	views:{
	"HospitalsDepartmentsview":{
	templateUrl:"templates/HospitalsDepartmentsview.html",
	controller:"HospitalsDepartmentsviewctrl",
	controllerAs:"HospitalsDepartmentsview"

}
}
}).state("HospitalDoctoradd",{
	url:"/HospitalDoctoradd",
	views:{
	"HospitalDoctoradd":{
	templateUrl:"templates/HospitalDoctoradd.html",
	controller:"HospitalDoctoraddctrl",
	controllerAs:"HospitalDoctoradd"

}
}

}).state("HospitalDoctorview",{
	url:"/HospitalDoctorview",
	views:{
	"HospitalDoctorview":{
	templateUrl:"templates/HospitalDoctorview.html",
	controller:"HospitalDoctorviewctrl",
	controllerAs:"HospitalDoctorview"

}
}
}).state("Hospitalinsurenceadd",{
	url:"/Hospitalinsurenceadd",
	views:{
	"Hospitalinsurenceadd":{
	templateUrl:"templates/Hospitalinsurenceadd.html",
	controller:"Hospitalinsurenceaddctrl",
	controllerAs:"Hospitalinsurenceadd"

}
}

}).state("Hospitalinsurenceview",{
	url:"/Hospitalinsurenceview",
	views:{
	"Hospitalinsurenceview":{
	templateUrl:"templates/Hospitalinsurenceview.html",
	controller:"Hospitalinsurenceviewctrl",
	controllerAs:"Hospitalinsurenceview"
}
}

});
});
