angular.module("sug", ['ui.router','ui.bootstrap','ngAnimate','ngSanitize']);
angular.module("sug").config(function($stateProvider,$urlRouterProvider){
	
$stateProvider.state("home",{
	url:"/home",
	views:{
	"":{
	templateUrl:"home.html",
	controller:"home-ctrl"
}
}

}).state("loginPopup",{
	url:"/loginPopup",
	views:{
	"":{
	templateUrl:"loginPopup.html",
	controller:"loginPopupctrl"
}
}

}).state("book-surgery-detail",{
	url:"/book-surgery-detail/:id",
	views:{
	"":{
	templateUrl:"book-surgery-detail.html",
	controller:"book-surgery-detail-ctrl"
}
}

}).state("book-surgery-login",{
	url:"/book-surgery-login",
	views:{
	"":{
	templateUrl:"book-surgery-login.html",
	controller:"book-surgery-login-ctrl"
	

}
}

}).state("book-surgery",{
	url:"/book-surgery/:id",
	views:{
	"":{
	templateUrl:"book-surgery.html",
	controller:"book-surgery-ctrl"
	

}
}

}).state("search",{
	url:"/search",
	views:{
	"":{
	templateUrl:"search-surgery.html",
	controller:"search-surgery-ctrl"
	

}
}

}).state("departmentview",{
	url:"/home",
	views:{
	"":{
	templateUrl:"home.html",
	controller:"departmentviewctrl"
}
}
}).state("dropdownview",{
	url:"/dropdown",
	views:{
	"":{
	templateUrl:"dropdown.html",
	controller:"dropdownctrl"
}
}
}).state("popup",{
	url:"/popup",
	views:{
	"":{
	templateUrl:"popup.html",
	controller:"popup-ctrl"
}
}
}).state("popupSmal",{
	url:"/popupSmal",
	views:{
	"":{
	templateUrl:"popupSmal.html",
	controller:"popupSmal-ctrl"
}
}
});

$urlRouterProvider.otherwise("/home");
});