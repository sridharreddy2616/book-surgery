angular.module('sug').service("urlservices",function (){
	this.viewBookSurgeryDetails="/hospetals/bsr/view?id=";
	this.viewAllBookSurgery="/hospetals/bsr/viewall";
	this.viewAllDepartments="/department/bsr/viewall";	
	this.viewAllDoctors="/hospitaldoctor/bsr/viewall";
	this.cityId="/hospetals/bsr/search";	
	this.cityViewAll="/city/bsr/viewall";
	// hospetals/bsr/search?city_id=k009&department_id=o134
});