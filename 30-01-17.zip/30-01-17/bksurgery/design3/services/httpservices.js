angular.module('sug').service("httpservices",function (urlservices,$http){
// view all book surgery
	this.viewAllBookSurgery=function(){
//
var response=$http({
    method: 'GET',
    url: urlservices.viewAllBookSurgery
});

return response; 
	}
	this.viewAllDoctors=function(){

var response=$http({
    method: 'GET',
    url: urlservices.viewAllDoctors
});

return response; 
	}

	this.viewBookSurgery=function(id){
var response=$http({
    method: 'GET',
    url: urlservices.viewBookSurgeryDetails+id
});
return response; 
	}

	
	this.viewAllDepartments=function(){
var response=$http({
    method: 'GET',
    url: urlservices.viewAllDepartments
});

return response; 
	}


	this.viewAllDoctors=function(){

var response=$http({
    method: 'GET',
    url: urlservices.viewAllDoctors
});

return response; 
	}

this.cityViewAll=function(){

var response=$http({
    method: 'GET',
    url: urlservices.cityViewAll
});

return response; 
	}	

this.cityId=function(city_id,department_id,departmentname){

var response=$http({
    method: 'GET',
    url:urlservices.cityId+"?city_id="+city_id+"&department_id="+department_id+"&departmentname="+departmentname
});

return response;
	}

});

