angular.module('sug').controller("popupSmal-ctrl",function ($scope,$uibModalInstance){

	alert("Hello");
 
 $scope.ok = function () {alert("Hello");
    $uibModalInstance.close({$value:selected.item});
  };

  $scope.cancel1 = function () {alert("Hello");
    $uibModalInstance.dismiss({$value:'cancel'});
  };
});