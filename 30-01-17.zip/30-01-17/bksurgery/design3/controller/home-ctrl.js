angular.module('sug').controller("home-ctrl",function ($state,$scope,$log,$rootScope,$uibModal,$http,httpservices,$stateParams){

  $scope.selected = $rootScope.cityName;
  $scope.bsreddy = $rootScope.departmentname;
  console.log($rootScope.departmentname,"Homectrl");
// For Date Picker start//

$scope.open2 = function() {
$scope.popup2.opened = true;
};
$scope.popup2 = {
opened: false
};
// For Date Picker end//

var response=httpservices.viewAllDepartments();
response.then(function(result){
$scope.viewAllDepartments=result.data;
console.log(result.data);
},function(result){
});  

var response=httpservices.viewAllBookSurgery();
response.then(function(result){
$scope.viewHospitals=result.data;

console.log(result.data);
},function(result){
});

var response=httpservices.cityViewAll();
response.then(function(result){
$scope.cityViewAll=result.data;
console.log(result.data);
},function(result){
});

$scope.bsr=function(){  
var city_id=$scope.selected.cityId;
var cityName=$scope.selected.cityName;
var department_id=$scope.bsreddy.departmentid;
var departmentname=$scope.bsreddy.departmentname;
//console.log(city_id+department_id+"data");
$rootScope.city_id=city_id;
$rootScope.cityName=cityName;
$rootScope.department_id=department_id;
$rootScope.departmentname=departmentname;
$state.go("book-surgery");
}

$scope.bsr2=function(){
var departmentname=$scope.bsreddy.departmentname;
// var response=httpservices.cityId(department_id);
$rootScope.departmentname=departmentname;
$state.go("book-surgery");
}


$scope.sri={};
$scope.homeimg=function(x){
	
	$scope.sri.department=x;	
}

  var items = ['item1', 'item2', 'item3'];

$scope.animationsEnabled1 = true;

  $scope.loginPopup = function (size, parentSelector) {
    var parentElem = parentSelector ? 
      angular.element($document[0].querySelector('.modal-demo ' + parentSelector)) : undefined;
    var modalInstance = $uibModal.open({
      animation: $scope.animationsEnabled1,
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-body',
      templateUrl: 'loginPopup.html',
      controller: 'loginPopupctrl',
      // controllerAs: '$ctrl',
      size: size,
      appendTo: parentElem,
      resolve: {
        items: function () {
          return $scope.items;
        }
      }
    });

    modalInstance.result.then(function (selectedItem) {
      $scope.selected = selectedItem;
    }, function () {
      $log.info('Modal dismissed at: ' + new Date());
    }); 

  };



$scope.myInterval = 5000;
  $scope.noWrapSlides = false;
  $scope.active = 0;
  var slides = $scope.slides = [];
  var currIndex = 0;

  $scope.addSlide = function() {
    var newWidth = 600 + slides.length + 1;
    slides.push({
      image: '//unsplash.it/' + newWidth + '/430',
      text: ['Nice image','Awesome photograph','That is so cool','I love that'][slides.length % 4],
      id: currIndex++
    });
  };

  $scope.randomize = function() {
    var indexes = generateIndexesArray();
    assignNewIndexesToSlides(indexes);
  };

  for (var i = 0; i < 4; i++) {
    $scope.addSlide();
  }

  // Randomize logic below

  function assignNewIndexesToSlides(indexes) {
    for (var i = 0, l = slides.length; i < l; i++) {
      slides[i].id = indexes.pop();
    }
  }

  function generateIndexesArray() {
    var indexes = [];
    for (var i = 0; i < currIndex; ++i) {
      indexes[i] = i;
    }
    return shuffle(indexes);
  }

  // http://stackoverflow.com/questions/962802#962890
  function shuffle(array) {
    var tmp, current, top = array.length;

    if (top) {
      while (--top) {
        current = Math.floor(Math.random() * (top + 1));
        tmp = array[current];
        array[current] = array[top];
        array[top] = tmp;
      }
    }

    return array;
  }



$scope.animationsEnabled = true;

  $scope.open = function (size, parentSelector) {
    var parentElem = parentSelector ? 
      angular.element($document[0].querySelector('.modal-demo ' + parentSelector)) : undefined;
    var modalInstance = $uibModal.open({
      animation: $scope.animationsEnabled,
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-body',
      templateUrl: 'popup.html',
      controller: 'popup-ctrl',
      // controllerAs: '$ctrl',
      size: size,
      appendTo: parentElem,
      resolve: {
        items: function () {
          return $scope.items;
        }
      }
    });

    modalInstance.result.then(function (selectedItem) {
      $scope.selected = selectedItem;
    }, function () {
      $log.info('Modal dismissed at: ' + new Date());
    }); 

  };



$scope.myInterval = 5000;
  $scope.noWrapSlides = false;
  $scope.active = 0;
  var slides = $scope.slides = [];
  var currIndex = 0;



  $scope.addSlide = function() {
    var newWidth = 800 + slides.length + 1;
    slides.push({
      image: '//unsplash.it/' + newWidth + '/430',
      text: ['Nice image','Awesome photograph','That is so cool','I love that'][slides.length % 4],
      id: currIndex++
    });
  };

  $scope.randomize = function() {
    var indexes = generateIndexesArray();
    assignNewIndexesToSlides(indexes);
  };

  for (var i = 0; i < 4; i++) {
    $scope.addSlide();
  }

  // Randomize logic below

  function assignNewIndexesToSlides(indexes) {
    for (var i = 0, l = slides.length; i < l; i++) {
      slides[i].id = indexes.pop();
    }
  }

  function generateIndexesArray() {
    var indexes = [];
    for (var i = 0; i < currIndex; ++i) {
      indexes[i] = i;
    }
    return shuffle(indexes);
  }

  // http://stackoverflow.com/questions/962802#962890
  function shuffle(array) {
    var tmp, current, top = array.length;

    if (top) {
      while (--top) {
        current = Math.floor(Math.random() * (top + 1));
        tmp = array[current];
        array[current] = array[top];
        array[top] = tmp;
      }
    }

    return array;
  }


  

  $scope.myhtml= 'I am an <code>HTML</code>string with ' +
     '<a href="#">links!</a> and other <em>stuff</em>'; 

});
