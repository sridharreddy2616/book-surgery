angular.module('sug').controller("search-surgery-ctrl",function ($scope,httpservices,$stateParams){

// For Typehed start//
  $scope.selected = undefined;
  $scope.bsreddy = undefined;
  // For Typehed end// 

// For Date Picker start//






$scope.open2 = function() {
$scope.popup2.opened = true;
};
$scope.popup2 = {
opened: false
};

$scope.search=function(){
	alert("giri");
}
// For Date Picker end//
var response=httpservices.cityViewAll();
response.then(function(result){
$scope.cityViewAll=result.data;
console.log(result.data);
},function(result){
});  


var response=httpservices.viewAllDepartments();
response.then(function(result){
$scope.viewAllDepartments=result.data;
console.log(result.data);
},function(result){
});  

var response=httpservices.viewAllBookSurgery();
response.then(function(result){
$scope.viewHospitals=result.data;

console.log(result.data);
},function(result){
});

$scope.bsr=function(){	
var city_id=$scope.selected.cityId;
var department_id=$scope.bsreddy.departmentid;
var response=httpservices.cityId(city_id,department_id);
response.then(function(result){
console.log("success");
$scope.cityId=result.data;

console.log(result.data);
},function(result){
});
}

var sample=[{name:"ECG"},{name:"MRI"},{name:"Bypass"},{name:"2d Echo"},{name:"Stant"}];
$scope.facilities=sample;
});
