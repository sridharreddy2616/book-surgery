angular.module('sug').controller("book-surgery-login-ctrl",function ($scope,$rootScope){

	$scope.abc=function(){
	$scope.x="this is book-surgery-login-ctrl",

	alert("Clicked book-surgery-login-ctrl");
	}

});