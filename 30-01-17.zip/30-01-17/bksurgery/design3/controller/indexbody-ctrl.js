angular.module('sug').controller("indexbody-ctrl",function ($scope,$rootScope){

	$scope.abc=function(){
	$scope.x="this is indexbody-ctrl",

	alert("Clicked indexbody-ctrl");
	}
});