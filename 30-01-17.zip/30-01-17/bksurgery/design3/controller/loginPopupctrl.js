angular.module('sug').controller("loginPopupctrl",function ($scope,$uibModalInstance,$log,$uibModal,$http,httpservices,$stateParams){
 
 $scope.ok = function () {
    $uibModalInstance.close({$value:selected.item});
  };

  $scope.cancel = function () {
    $uibModalInstance.dismiss({$value:'cancel'});
  };
});