angular.module('sug').controller("popup-ctrl",function ($scope,$uibModalInstance,$log,$uibModal,$http,httpservices,$stateParams){
 
 $scope.ok = function () {
    $uibModalInstance.close({$value:selected.item});
  };

  $scope.cancel = function () {
    $uibModalInstance.dismiss({$value:'cancel'});
  };
  
 $scope.open1 = function (size, parentSelector) {
    var parentElem = parentSelector ? 
      angular.element($document[0].querySelector('.modal-demo ' + parentSelector)) : undefined;
    var modalInstance = $uibModal.open({
      animation: $scope.animationsEnabled,
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-body',
      templateUrl: 'popupSmal.html',
      controller: 'popup-ctrl',
      // controllerAs: '$ctrl',
      size: size,
      appendTo: parentElem,
      resolve: {
        items: function () {
          return $scope.items;
        }
      }
    });

    modalInstance.result.then(function (selectedItem) {
      $scope.selected = selectedItem;
    }, function () {
      $log.info('Modal dismissed at: ' + new Date());
    }); 

  };


});