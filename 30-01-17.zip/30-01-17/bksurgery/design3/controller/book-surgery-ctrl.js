angular.module('sug').controller("book-surgery-ctrl",function ($scope,httpservices,$stateParams,$rootScope){

// For Typehed start//
  $scope.selected = $rootScope.cityName;
  $scope.bsreddy = $rootScope.departmentname;  
  console.log($rootScope.departmentname);
  console.log("Sridhar");
  // For Typehed end// 

// For Date Picker start//

$scope.open2 = function() {
$scope.popup2.opened = true;
};
$scope.popup2 = {
opened: false
};
// For Date Picker end//
var response=httpservices.cityViewAll();
response.then(function(result){
$scope.cityViewAll=result.data;
console.log(result.data);
},function(result){
});  


var response=httpservices.viewAllDepartments();
response.then(function(result){
$scope.viewAllDepartments=result.data;
console.log(result.data);
},function(result){
});  

var response=httpservices.viewAllBookSurgery();
response.then(function(result){
$scope.viewHospitals=result.data;

console.log(result.data);
},function(result){
});

	
var city_id=$rootScope.city_id;
var department_id=$rootScope.department_id;
var departmentname=$rootScope.departmentname;
var response=httpservices.cityId(city_id,department_id,departmentname);
// var response=httpservices.cityId(city_id);
response.then(function(result){
console.log("success");
$scope.cityId=result.data;
console.log(result.data);
},function(result){
});

$scope.bsr=function(){	
var city_id=$scope.selected.cityId;
var department_id=$scope.bsreddy.departmentid;
var departmentname=$scope.bsreddy.departmentname;
var response=httpservices.cityId(city_id,department_id,departmentname);
response.then(function(result){
console.log("success");
$scope.cityId=result.data;
console.log(result.data);
},function(result){
});
}


var sample=[{name:"ECG"},{name:"MRI"},{name:"Bypass"},{name:"2d Echo"},{name:"Stant"}];
$scope.facilities=sample;
});
