angular.module("sug").controller("departmentviewctrl",function ($scope,$rootScope,$http){

	var departmentApi="/department/bsr/search";

var response=$http({
    method: 'GET',
    url: departmentApi
});response.then(function(result){
	$scope.viewdepartment=result.data;
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});
});




