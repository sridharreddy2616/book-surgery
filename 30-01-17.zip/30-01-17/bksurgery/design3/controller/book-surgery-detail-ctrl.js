angular.module('sug').controller("book-surgery-detail-ctrl",function ($scope,$stateParams,httpservices){
var id=$stateParams.id
var response=httpservices.viewBookSurgery(id);
response.then(function(result){
	console.log("success");
$scope.viewHospital=result.data;


},function(result){
	console.log("error");
});


var response=httpservices.viewAllDoctors(id);

response.then(function(result){
	console.log("success");
$scope.viewAllDoctors=result.data;


},function(result){
	console.log("error");
});


var response=httpservices.viewAllDepartments();
response.then(function(result){
$scope.viewAllDepartments=result.data;
console.log(result.data);
},function(result){
});  



$scope.myInterval = 5000;
  $scope.noWrapSlides = false;
  $scope.active = 0;
  var slides = $scope.slides = [];
  var currIndex = 0;

  $scope.addSlide = function() {
    var newWidth = 600 + slides.length + 1;
    slides.push({
      image: '//unsplash.it/' + newWidth + '/300',
      text: ['Nice image','Awesome photograph','That is so cool','I love that'][slides.length % 4],
      id: currIndex++
    });
  };

  $scope.randomize = function() {
    var indexes = generateIndexesArray();
    assignNewIndexesToSlides(indexes);
  };

  for (var i = 0; i < 4; i++) {
    $scope.addSlide();
  }

  // Randomize logic below

  function assignNewIndexesToSlides(indexes) {
    for (var i = 0, l = slides.length; i < l; i++) {
      slides[i].id = indexes.pop();
    }
  }

  function generateIndexesArray() {
    var indexes = [];
    for (var i = 0; i < currIndex; ++i) {
      indexes[i] = i;
    }
    return shuffle(indexes);
  }

  // http://stackoverflow.com/questions/962802#962890
  function shuffle(array) {
    var tmp, current, top = array.length;

    if (top) {
      while (--top) {
        current = Math.floor(Math.random() * (top + 1));
        tmp = array[current];
        array[current] = array[top];
        array[top] = tmp;
      }
    }

    return array;
  }
});