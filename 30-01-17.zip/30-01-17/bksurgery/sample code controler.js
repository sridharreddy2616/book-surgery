angular.module('sug').controller("book-surgery-ctrl",function ($scope,$rootScope,$http){

  $scope.open2 = function() {
    $scope.popup2.opened = true;
  };

  $scope.popup2 = {
    opened: false
  };
  
var countryApi="/hospetals/bsr/viewall";

var response=$http({
    method: 'GET',
    url: countryApi
});response.then(function(result){
$scope.viewHospitals=result.data;

},function(result){
});

//$scope.sample=["sample1","sample2","sample3","sample4"];


console.log("book surgery");
	$scope.abc=function(){
	$scope.x="this is book-surgery-ctrl",

	alert("Clicked book-surgery-ctrl");
	}

});





//sample for view data from data base//


angular.module('sug').controller("book-surgery-ctrl",function ($scope,$rootScope,$http){


var countryApi="/hospetals/bsr/viewall";

var response=$http({
    method: 'GET',
    url: countryApi
});response.then(function(result){
$scope.viewCountry=result.data;
console.log("success");
console.log(result);
},function(result){
console.log("erro");
console.log(result);
});



console.log("book surgery");
  $scope.abc=function(){
  $scope.x="this is book-surgery-ctrl",

  alert("Clicked book-surgery-ctrl");
  }

});
