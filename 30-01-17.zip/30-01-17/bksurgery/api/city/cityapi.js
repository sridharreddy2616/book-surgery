var express=require("express");
var citySchema=require("./citySchema");
var bodyParser=require("body-parser");
var cityApi=express.Router();
cityApi.post("/add",function(req,res){
	var cityName=req.body.cityName;
	var cityId=req.body.cityId;
	var stateId=req.body.stateId;
	var countryId=req.body.countryId;
	var createdDate=req.body.createdDate;
	
	var city=new citySchema({
	cityName:cityName,
	cityId:req.body.cityId,
	stateId:stateId,
	countryId:countryId,
	createdDate:createdDate,
});
	city.save(function(err){
	if(err){res.send("Sorry Somthing error")}
	else{res.send("successfully created account")}
});
	});

cityApi.get("/view",function(req,res){
	citySchema.find({_id:req.query.id},function(err,data){
		if(err){res.send('error');}
		else{res.send(data);}
	});	
});

cityApi.get("/viewAll",function(req,res){
	citySchema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});

cityApi.put("/edit",function(req,res){
citySchema.findById(req.body.id,function(err,citySch){
	if(err){res.send(err);} else{
		citySch.cityName = req.body.cityName;
		citySch.cityId = req.body.cityId;
		citySch.stateId = req.body.stateId;
		citySch.countryId = req.body.countryId;
		citySch.createdDate = req.body.createdDate;
		// citySch.save(function(err){
		// 	if(err){res.send(err)}
		// 	else{res.json({message:'city data updated!'});}
		// });
	}
});

});

cityApi.delete("/delete",function(req,res){
	citySchema.findByIdAndRemove(req.body.id,function(err,data){
		if(err){res.send("error")}
		else{res.send(data)}
	});
});
cityApi.get("/search",function(req,res){
	citySchema.find({cityName:req.query.name},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});



module.exports = cityApi;

	
// // api.use('/akhil/alok/sri',api);