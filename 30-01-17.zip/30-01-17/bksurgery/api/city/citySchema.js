var mongoose=require("mongoose");
var stateSchema=mongoose.Schema;
var staSchema=new stateSchema({
	cityName:String,
	cityId:String,
	stateId:String,
	countryId:String,
	createdDate:String
});
module.exports=mongoose.model("City",staSchema);