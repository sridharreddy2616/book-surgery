var express = require("express");
var countrySchema = require("./schema");
var bodyParser = require("body-parser");
var api = express.Router();
api.post("/add",function(req,res){
	var name=req.body.name;
	var id=req.body.id;
	var crdate=req.body.crdate;
	
	var cnt=new countrySchema({
	cntName:name,
	cntId:id,
	cntDate:crdate
});
	cnt.save(function(err){
	if(err){res.send("Sorry Somthing error")}
	else{res.send(name+"--success----"+id)}
});
	});

api.get("/view",function(req,res){
	countrySchema.find({_id:req.query.id},function(err,data){
		if(err){res.send('error');}
		else{res.send(data);}
	});	
});

api.put("/edit",function(req,res){
countrySchema.findById(req.body.id,function(err,countrySch){
	if(err){res.send(err);} else{
		countrySch.cntName = req.body.name;
		countrySch.cntId = req.body.id;
		countrySch.cntCrdate = req.body.crdate;
		countrySch.save(function(err){
			if(err){res.send(err)}
			else{res.json({message:'country data updated!'});}
		});
	}
});

});
api.delete("/delete",function(req,res){
	countrySchema.findByIdAndRemove(req.body.id,function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});
api.get("/search",function(req,res){
	countrySchema.find({cntName:req.query.name},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});

api.get("/viewAll",function(req,res){
	countrySchema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});

module.exports = api;

