var mongoose=require("mongoose");
var countrySchema=mongoose.Schema;
var cntSchema=new countrySchema({
	cntName:String,
	cntId:String,
	cntDate:String
});
module.exports=mongoose.model("Country",cntSchema);