var mongoose=require("mongoose");
var adminSchema=mongoose.Schema;
var adminSchema=new adminSchema({
	userName:String,
	pasSword:String	
});
module.exports=mongoose.model("admin",adminSchema);