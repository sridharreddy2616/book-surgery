var express=require("express");
var adminSchema=require("./adminschema");
var bodyParser=require("body-parser");

var adminApi=express.Router();


adminApi.post("/add",function(req,res){
	var username=req.body.username;
	var password=req.body.password;
	
	
	var adm=new adminSchema({
	userName:username,
	pasSword:password,	
});

	adm.save(function(err){
	if(err){res.send("Sorry Somthing error")}
	else{res.send("successfully created account")}
});
	});


adminApi.get("/login",function(req,res){
	adminSchema.findOne({username:req.query.username},{password:req.query.password},function(err,data){		
		//if(data=="" || data==null){res.send("error login");}
		//else{res.send("successfully login");}	
		//res.send(req.query.username+req.query.password);
		// if(data.length==0){
		// res.send("200");	
		// } else{
		// res.send("201");	
		// }

		if(err){res.send("err")}
		else{res.send(data)}
		
	});	
});

adminApi.get("/viewAll",function(req,res){
	adminSchema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});


module.exports = adminApi;