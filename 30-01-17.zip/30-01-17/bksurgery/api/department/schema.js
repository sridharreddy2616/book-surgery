var mongoose=require("mongoose");
var departmentSchema=mongoose.Schema;
var cntSchema=new departmentSchema({
	departmentname:String,
	departmentid:String,
	categories:String	
});

module.exports=mongoose.model("department",cntSchema);



