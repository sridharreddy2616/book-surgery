var express=require("express");
var departmentSchema=require("./schema");
var bodyParser=require("body-parser");
var departmentApi=express.Router();
departmentApi.post("/add",function(req,res){
	var departmentname=req.body.departmentname;
	var departmentid=req.body.departmentid;
	var categories=req.body.categories;
	var crdate=req.body.crdate;

	var cnt=new departmentSchema({
		departmentname:departmentname,
		departmentid:departmentid,
		categories:categories,
		cntCrdate:crdate,
});
	cnt.save(function(err){
	if(err){res.send("Sorry Somthing error");}
	else{res.send(departmentname+departmentid+categories);}
});
	});

departmentApi.get("/view",function(req,res){
	departmentSchema.find({_id:req.query.id},function(err,data){
		if(err){res.send('error');}
		else{res.send(data);}
	});
});

departmentApi.put("/edit",function(req,res){
departmentSchema.findById(req.body.id,function(err,departmentSch){
	if(err){res.send(err);} else{
		departmentSch.departmentname = req.body.departmentname;
		departmentSch.departmentid = req.body.departmentid;
		departmentSch.categories = req.body.categories;
		departmentSch.save(function(err){
			if(err){res.send(err)}
			else{res.json({message:'department data updated!'});}
		});
	}
});
	});

departmentApi.delete("/delete",function(req,res){
	departmentSchema.findByIdAndRemove(req.body.id,function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});
departmentApi.get("/search",function(req,res){
	departmentSchema.find({departmentname:req.query.name},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});

departmentApi.get("/viewAll",function(req,res){
	departmentSchema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});

module.exports = departmentApi;


// // api.use('/akhil/alok/sri',api);
