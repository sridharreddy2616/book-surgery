var mongoose=require("mongoose");
var countrySchema=mongoose.Schema;
var cntSchema=new countrySchema({
	cntDepartment:String,
	cntProcedure:String,
	cntProcedureid:String,
	cntDate:String
});
module.exports=mongoose.model("procedure",cntSchema);