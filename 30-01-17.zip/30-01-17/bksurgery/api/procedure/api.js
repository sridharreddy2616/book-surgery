var express=require("express");
var procedureSchema=require("./schema");
var bodyParser=require("body-parser");
var api=express.Router();
api.post("/add",function(req,res){
	var department_id=req.body.department_id;
	var procedure_name=req.body.procedure_name;
	var procedure_id=req.body.procedure_id;
	var crdate=req.body.crdate;
	//res.send(name+id+crdate);
	var cnt=new procedureSchema({
		cntDepartment:department_id,
		cntProcedure:procedure_name,
		cntProcedureid:procedure_id,
		cntDate:crdate,
	});
	cnt.save(function(err){
		if(err){res.send("sorry somthing error")}
			else{res.send("successfully created account")}

	});
});
api.get("/view",function(req,res){
	procedureSchema.find({_id:req.query.department_id},function(err,data){
if(err){res.send("err")}
	else{res.send(data)}
	});
});
api.get("/viewAll",function(req,res){
	procedureSchema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});
api.put("/edit",function(req,res){
procedureSchema.findById(req.body.id,function(err,procedureSch){
	if(err){res.send(err);} else{
		procedureSch.cntDepartment = req.body.department_id;
		procedureSch.cntProcedure = req.body.procedure_name;
		procedureSch.cntProcedureid=req.body.procedure_id
		procedureSch.cntCrdate = req.body.crdate;
		procedureSch.save(function(err){
			if(err){res.send(err)}
			else{res.json({message:'procedure data updated!'});}
		});
	}
});

});
api.delete("/delete",function(req,res){
	procedureSchema.findByIdAndRemove(req.body.procedure_id,function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});
api.get("/search",function(req,res){
	procedureSchema.find({cntProcedure:req.query.procedure_name},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});

api.get("/viewAll",function(req,res){
	procedureSchema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});
module.exports= api;