var express=require("express");
var stateSchema=require("./stateSchema");
var bodyParser=require("body-parser");

var stateApi=express.Router();


stateApi.post("/add",function(req,res){
	var name=req.body.name;
	var stateid=req.body.stateid;
	var countryid=req.body.countryid;
	var date=req.body.date;
	
	var sta=new stateSchema({
	stateName:name,
	stateId:stateid,
	countryId:countryid,
	createdDate:date,
});
	sta.save(function(err){
	if(err){res.send("Sorry Somthing error")}
	else{res.send("successfully created account")}
});
	});

stateApi.get("/view",function(req,res){
	stateSchema.find({_id:req.query.id},function(err,data){
		if(err){res.send('error');}
		else{res.send(data);}
	});	
});

stateApi.get("/viewAll",function(req,res){
	stateSchema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});

stateApi.put("/edit",function(req,res){
stateSchema.findById(req.body.id,function(err,stateSch){
	if(err){res.send(err);} else{
		stateSch.stateName = req.body.name;
		stateSch.stateId = req.body.id;
		stateSch.countryId = req.body.crid;
		stateSch.createdDate = req.body.stdate;
		stateSch.save(function(err){
			if(err){res.send(err)}
			else{res.json({message:'state data updated!'});}
		});
	}
});

});

stateApi.delete("/delete",function(req,res){
	stateSchema.findByIdAndRemove(req.body.id,function(err,data){
		if(err){res.send("error")}
		else{res.send(data)}
	});
});
stateApi.get("/search",function(req,res){
	stateSchema.find({staName:req.query.name},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});



module.exports = stateApi;

	
// // api.use('/akhil/alok/sri',api);