var mongoose=require("mongoose");
var stateSchema=mongoose.Schema;
var staSchema=new stateSchema({
	stateName:String,
	stateId:String,
	countryId:String,
	createdDate:String
});
module.exports=mongoose.model("State",staSchema);