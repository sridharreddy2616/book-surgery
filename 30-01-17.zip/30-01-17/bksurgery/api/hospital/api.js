var express=require("express");
var hospitalSchema=require("./schema");
var bodyParser=require("body-parser");
var api=express.Router();
api.post("/add",function(req,res){
	var hospital_name=req.body.hospital_name;
	var hospital_id=req.body.hospital_id;
	var country_name=req.body.country_name;
	var state_name=req.body.state_name;
	var city_name=req.body.city_name;
	var city_id=req.body.city_id;
	var department_id=req.body.department_id;
	var pincode=req.body.pincode;
	var logitude=req.body.logitude;
	var latitude=req.body.latitude;
	var description=req.body.description;
	var crdate=req.body.crdate;
	//res.send(name+id+crdate);
	var hot=new hospitalSchema({
	hospital_name:hospital_name,
	hospital_id:hospital_id,
	country_name:country_name,
 	state_name:state_name,
	city_name:city_name,
	city_id:city_id,
	department_id:department_id,
	pincode:pincode,
	logitude:logitude,
	latitude:latitude,
	description:description,
	crdate:crdate,

	});
	hot.save(function(err){
		if(err){res.send("sorry somthing error")}
			else{res.send("successfully created account")}

	});
});
api.get("/view",function(req,res){
	hospitalSchema.find({_id:req.query.id},function(err,data){
if(err){res.send("err")}
	else{res.send(data)}
	});
});
api.get("/viewAll",function(req,res){
	hospitalSchema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});
api.put("/edit",function(req,res){
hospitalSchema.findById(req.body.id,function(err,hospitalSchema){
	if(err){res.send(err);} else{
		hospitalSchema.hospital_name=req.body.hospital_name;
		hospitalSchema.hospital_id=req.body.hospital_id;
	hospitalSchema.country_name=req.body.country_name;
	hospitalSchema.state_name=req.body.state_name;
	hospitalSchema.city_name=req.body.city_name;
	hospitalSchema.city_id=req.body.city_id;
	hospitalSchema.department_id=req.body.department_id;
	hospitalSchema.pincode_name=req.body.pincode_name;
	hospitalSchema.logitude=req.body.logitude;
	hospitalSchema.latitude=req.body.latitude;
	hospitalSchema.description=req.body.description;
	hospitalSchema.crdate=req.body.crdate;
		hospitalSchema.save(function(err){
			if(err){res.send(err)}
			else{res.json({message:'hospital data updated!'});}
		});
	}
});

});
api.delete("/delete",function(req,res){
	hospitalSchema.findByIdAndRemove(req.body.id,function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});





// api.get("/search",function(req,res){
// 	hospitalSchema.find({hospital_name:req.query.hospital_name},function(err,data){
// 		if(err){res.send("err")}
// 		else{res.send(data)}
// 	});
// });


api.get("/viewAll",function(req,res){
	hospitalSchema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});




api.get("/search",function(req,res){
	hospitalSchema.find({city_id:req.query.city_id,department_id:req.query.department_id},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});

module.exports= api;