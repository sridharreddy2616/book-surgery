var express=require("express");
var hosprocedureSchema=require("./procedureschema");
var bodyParser=require("body-parser");
var hosprocedureApi=express.Router();

hosprocedureApi.post("/add",function(req,res){
	var deportment=req.body.deportment;
	var lowprice=req.body.lowprice;
	var display=req.body.display;	
	var date=req.body.date;
	
	var hospro=new hosprocedureSchema({
		 hos_deportment:deportment,
		 hos_lowprice:lowprice,
	 	 hos_display:display,		 
		 hos_date:date,
	});
	hospro.save(function(err){
		if(err){res.send("sorry somthing error")}
			else{res.send("successfully created account")}

	});
});
hosprocedureApi.get("/view",function(req,res){
	hosprocedureSchema.find({_id:req.query.id},function(err,data){
if(err){res.send("err")}
	else{res.send(data)}
	});
});
hosprocedureApi.get("/viewAll",function(req,res){
	hosprocedureSchema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});
hosprocedureApi.put("/edit",function(req,res){
hosprocedureSchema.findById(req.body.id,function(err,hosprocedureSchema){
	if(err){res.send(err);} else{	
	hosprocedureSchema.hos_deportment=req.body.deportment;
	hosprocedureSchema.hos_lowprice=req.body.lowprice;
	hosprocedureSchema.hos_display=req.body.display;	
	hosprocedureSchema.hos_date=req.body.date;
		hosprocedureSchema.save(function(err){
			if(err){res.send(err)}
			else{res.json({message:'surgeon data updated!'});}
		});
	}
});

});
hosprocedureApi.delete("/delete",function(req,res){
	hosprocedureSchema.findByIdAndRemove(req.body.id,function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});
hosprocedureApi.get("/search",function(req,res){
	hosprocedureSchema.find({hos_deportment:req.query.deportment},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});

hosprocedureApi.get("/viewAll",function(req,res){
	hosprocedureSchema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});

module.exports= hosprocedureApi;