var express=require("express");
var surgeonSchema=require("./surgeonschema");
var bodyParser=require("body-parser");
var surgeonApi=express.Router();

surgeonApi.post("/add",function(req,res){
	var name=req.body.name;
	var degignation=req.body.degignation;
	var experience=req.body.experience;
	var mailid=req.body.mailid;
	var phonenumber=req.body.phonenumber;
	var picture=req.body.picture;
	var description=req.body.description;
	var date=req.body.date;
	//res.send(name+id+crdate);
	var sur=new surgeonSchema({
		 surgeon_name:name,
		 surgeon_degignation:degignation,
	 	 state_experience:experience,
		 surgeon_mailid:mailid,
		 surgeon_phonenumber:phonenumber,
		 surgeon_picture:picture,
		 surgeon_description:description,
		 surgeon_date:date,

	});
	sur.save(function(err){
		if(err){res.send("sorry somthing error")}
			else{res.send("successfully created account")}

	});
});
surgeonApi.get("/view",function(req,res){
	surgeonSchema.find({_id:req.query.id},function(err,data){
if(err){res.send("err")}
	else{res.send(data)}
	});
});
surgeonApi.get("/viewAll",function(req,res){
	surgeonSchema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});
surgeonApi.put("/edit",function(req,res){
surgeonSchema.findById(req.body.id,function(err,surgeonSchema){
	if(err){res.send(err);} else{	
	surgeonSchema.name=req.body.name;
	surgeonSchema.degignation=req.body.degignation;
	surgeonSchema.experience=req.body.experience;
	surgeonSchema.mailid=req.body.mailid;
	surgeonSchema.phonenumber=req.body.phonenumber;
	surgeonSchema.picture=req.body.picture;
	surgeonSchema.description=req.body.description;
	surgeonSchema.date=req.body.date;
		surgeonSchema.save(function(err){
			if(err){res.send(err)}
			else{res.json({message:'surgeon data updated!'});}
		});
	}
});

});
surgeonApi.delete("/delete",function(req,res){
	surgeonSchema.findByIdAndRemove(req.body.id,function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});
surgeonApi.get("/search",function(req,res){
	surgeonSchema.find({surgeon_name:req.query.name},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});

surgeonApi.get("/viewAll",function(req,res){
	surgeonSchema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});

module.exports= surgeonApi;