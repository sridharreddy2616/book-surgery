var mongoose=require("mongoose");
var insurenceSchema=mongoose.Schema;
var insu=new insurenceSchema({
	 	 name:String,
	 	 insurencename:String,
	 	 // img:{data:Buffer, contentType:String}
		 photo:String	
		   
});
module.exports=mongoose.model("insurence",insu);

 		