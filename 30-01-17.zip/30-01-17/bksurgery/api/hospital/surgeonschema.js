var mongoose=require("mongoose");
var surgeonSchema=mongoose.Schema;
var surSchema=new surgeonSchema({
	 surgeon_name:String,
	 surgeon_degignation:String,
 	 state_experience:String,
	 surgeon_mailid:String,
	 surgeon_phonenumber:String,
	 surgeon_picture:String,
	 surgeon_description:String,
	 surgeon_date:String,
});
module.exports=mongoose.model("surgeon",surSchema);


