var mongoose=require("mongoose");
var hospitadoctorschema=mongoose.Schema;
var hospitadoctorschema=new hospitadoctorschema({
	doctorname:String,
	 doctordesignation:String,
 	 doctorexperience:String,
	 doctordepertment:String,
	 doctorid:String,
	 
});
module.exports=mongoose.model("hospitaldoctor",hospitadoctorschema);

