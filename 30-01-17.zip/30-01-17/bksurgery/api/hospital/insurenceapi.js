var express=require("express");
var insurenceSchema=require("./insurenceschema");
var bodyParser=require("body-parser");
var fs=require("fs");
var multer=require("multer");
var insurenceApi=express.Router();


insurenceApi.post("/add",function(req,res){
	var name=req.body.name;
	var insurencename=req.body.insurencename;
	var photo=req.body.photo;
	// var newItem.img.data=fs.readFilesSync(req.files.userPhoto.path)
	// 	newItem.img.contentType = 'image/png';
	
	
	var insu=new insurenceSchema({
		 name:name,
		 insurencename:req.body.insurencename,
		 photo:photo,	 
		 
	});
	insu.save(function(err){
		if(err){res.send("sorry somthing error")}
			else{res.send("successfully created account")}

	});
});

insurenceApi.get("/view",function(req,res){
	insurenceSchema.find({_id:req.query.id},function(err,data){
if(err){res.send("err")}
	else{res.send(data)}
	});
});
insurenceApi.get("/viewAll",function(req,res){
	insurenceSchema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});
insurenceApi.put("/edit",function(req,res){
insurenceSchema.findById(req.body.id,function(err,insurenceSchema){
	if(err){res.send(err);} else{	
	insurenceSchema.insu_name=req.body.name;
	insurenceSchema.insu_photo=req.body.photo;
	insurenceSchema.insu_date=req.body.date;	
	
		insurenceSchema.save(function(err){
			if(err){res.send(err)}
			else{res.json({message:'surgeon data updated!'});}
		});
	}
});

});
insurenceApi.delete("/delete",function(req,res){
	insurenceSchema.findByIdAndRemove(req.body.id,function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});
insurenceApi.get("/search",function(req,res){
	insurenceSchema.find({insu_name:req.query.name},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});
insurenceApi.get("/viewAll",function(req,res){
	insurenceSchema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});

module.exports= insurenceApi;