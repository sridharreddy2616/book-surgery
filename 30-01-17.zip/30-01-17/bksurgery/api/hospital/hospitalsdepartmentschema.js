var mongoose=require("mongoose");
var hospitalsdepartmentschema=mongoose.Schema;
var hospitalsdepartmentschema=new hospitalsdepartmentschema({
	hospitalid:String,
	departmentid:String
 	 
});
module.exports=mongoose.model("hospitaldepartment",hospitalsdepartmentschema);