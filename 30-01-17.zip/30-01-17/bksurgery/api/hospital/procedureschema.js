var mongoose=require("mongoose");
var hosprocedureSchema=mongoose.Schema;
var hospro=new hosprocedureSchema({
	 	 hos_deportment:String,
		 hos_lowprice:String,
	 	 hos_display:String,		 
		 hos_date:String,  
});
module.exports=mongoose.model("hosprocedure",hospro);


		