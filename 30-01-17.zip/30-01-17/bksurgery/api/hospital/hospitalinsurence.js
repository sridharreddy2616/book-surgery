var express=require("express");
var hospitalinsurenceschema=require("./hospitalinsurenceschema");
var bodyParser=require("body-parser");
var hospitalinsurenceApi=express.Router();

hospitalinsurenceApi.post("/add",function(req,res){
	var hospitalid=req.body.hospitalid;
	var insurenceid=req.body.insurenceid;
	
	
	var insu=new hospitalinsurenceschema({
		 hospitalid:hospitalid,
		 insurenceid:insurenceid	 
	});

	insu.save(function(err){
		if(err){res.send("sorry somthing error")}
			else{res.send("successfully created account")}

	});
});
hospitalinsurenceApi.get("/view",function(req,res){
	hospitalinsurenceschema.find({_id:req.query.id},function(err,data){
if(err){res.send("err")}
	else{res.send(data)}
	});
});
hospitalinsurenceApi.get("/viewAll",function(req,res){
	hospitalinsurenceschema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});
hospitalinsurenceApi.put("/edit",function(req,res){
hospitalinsurenceschema.findById(req.body.id,function(err,hospitalinsurenceschema){
	if(err){res.send(err);} else{	
	hospitalinsurenceschema.hospitalid=req.body.hospitalid;
	hospitalinsurenceschema.insurenceid=req.body.insurenceid;	
		hospitalinsurenceschema.save(function(err){
			if(err){res.send(err)}
			else{res.json({message:'surgeon data updated!'});}
		});
	}
});

});
hospitalinsurenceApi.delete("/delete",function(req,res){
	hospitalinsurenceschema.findByIdAndRemove(req.body.id,function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});
hospitalinsurenceApi.get("/search",function(req,res){
	hospitalinsurenceschema.find({hospitalid:req.query.hospitalid},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});
hospitalinsurenceApi.get("/viewAll",function(req,res){
	hospitalinsurenceschema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});

module.exports= hospitalinsurenceApi;