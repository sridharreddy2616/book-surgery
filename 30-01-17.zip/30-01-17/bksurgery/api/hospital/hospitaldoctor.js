var express=require("express");
var hospitadoctorschema=require("./hospitaldoctorschema");
var bodyParser=require("body-parser");
var hospitaldoctorApi=express.Router();

hospitaldoctorApi.post("/add",function(req,res){
	var doctorname=req.body.doctorname;
	var doctordesignation=req.body.doctordesignation;
	var doctorexperience=req.body.doctorexperience;
	var doctordepertment=req.body.doctordepertment;
	var doctorid=req.body.doctorid;
	
	var insu=new hospitadoctorschema({
		 doctorname:doctorname,
		 doctordesignation:doctordesignation,
		 doctorexperience:doctorexperience,
		 doctordepertment:doctordepertment,	
		 doctorid:doctorid 
	});

	insu.save(function(err){
		if(err){res.send("sorry somthing error")}
			else{res.send("successfully created account")}

	});
});
hospitaldoctorApi.get("/view",function(req,res){
	hospitadoctorschema.find({_id:req.query.id},function(err,data){
if(err){res.send("err")}
	else{res.send(data)}
	});
});
hospitaldoctorApi.get("/viewAll",function(req,res){
	hospitadoctorschema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});
hospitaldoctorApi.put("/edit",function(req,res){
hospitadoctorschema.findById(req.body.id,function(err,hospitadoctorschema){
	if(err){res.send(err);} else{	
	hospitadoctorschema.doctorname=req.body.doctorname;
	hospitadoctorschema.doctordesignation=req.body.doctordesignation;
		hospitadoctorschema.doctorexperience=req.body.doctorexperience;
		hospitadoctorschema.doctordepertment=req.body.doctordepertment;
		hospitadoctorschema.doctorid=req.body.doctorid;
		hospitadoctorschema.save(function(err){
			if(err){res.send(err)}
			else{res.json({message:'surgeon data updated!'});}
		});
	}
});

});
hospitaldoctorApi.delete("/delete",function(req,res){
	hospitadoctorschema.findByIdAndRemove(req.body.id,function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});
hospitaldoctorApi.get("/search",function(req,res){
	hospitadoctorschema.find({doctorname:req.query.doctorname},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});
hospitaldoctorApi.get("/viewAll",function(req,res){
	hospitadoctorschema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});

module.exports= hospitaldoctorApi;