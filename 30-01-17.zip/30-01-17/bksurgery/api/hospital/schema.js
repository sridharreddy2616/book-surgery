var mongoose=require("mongoose");
var hospitalSchema=mongoose.Schema;
var hotSchema=new hospitalSchema({
	hospital_name:String,
	hospital_id:String,
	 country_name:String,
 	 state_name:String,
	 city_name:String,
	 city_id:String,
	 department_id:String,
	 pincode:String,
	 logitude:String,
	 latitude:String,
	 description:String,
	crdate:String,
});
module.exports=mongoose.model("hospital",hotSchema);
