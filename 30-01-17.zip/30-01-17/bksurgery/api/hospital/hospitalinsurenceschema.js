var mongoose=require("mongoose");
var hospitalSchema=mongoose.Schema;
var hotSchema=new hospitalSchema({
	hospitalid:String,
	 insurenceid:String
 	 
});
module.exports=mongoose.model("hospitalInsurence",hotSchema);