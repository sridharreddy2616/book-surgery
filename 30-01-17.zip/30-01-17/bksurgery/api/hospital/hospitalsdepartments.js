var express=require("express");
var hospitalsdepartmentschema=require("./hospitalsdepartmentschema");
var bodyParser=require("body-parser");
var hospitalsdepartmentApi=express.Router();

hospitalsdepartmentApi.post("/add",function(req,res){
	var hospitalid=req.body.hospitalid;
	var departmentid=req.body.departmentid;
	
	
	var insu=new hospitalsdepartmentschema({
		 hospitalid:hospitalid,
		 departmentid:departmentid	 
	});

	insu.save(function(err){
		if(err){res.send("sorry somthing error")}
			else{res.send("successfully created account")}

	});
});
hospitalsdepartmentApi.get("/view",function(req,res){
	hospitalsdepartmentschema.find({_id:req.query.id},function(err,data){
if(err){res.send("err")}
	else{res.send(data)}
	});
});
hospitalsdepartmentApi.get("/viewAll",function(req,res){
	hospitalsdepartmentschema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});
hospitalsdepartmentApi.put("/edit",function(req,res){
hospitalsdepartmentschema.findById(req.body.id,function(err,hospitalsdepartmentschema){
	if(err){res.send(err);} else{	
	hospitalsdepartmentschema.hospitalid=req.body.hospitalid;
	hospitalsdepartmentschema.departmentid=req.body.departmentid;	
		hospitalsdepartmentschema.save(function(err){
			if(err){res.send(err)}
			else{res.json({message:'surgeon data updated!'});}
		});
	}
});

});
hospitalsdepartmentApi.delete("/delete",function(req,res){
	hospitalsdepartmentschema.findByIdAndRemove(req.body.id,function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});
hospitalsdepartmentApi.get("/search",function(req,res){
	hospitalsdepartmentschema.find({hospitalid:req.query.hospitalid},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});
});
hospitalsdepartmentApi.get("/viewAll",function(req,res){
	hospitalsdepartmentschema.find({},function(err,data){
		if(err){res.send("err")}
		else{res.send(data)}
	});

});

module.exports= hospitalsdepartmentApi;